from pg_connection import get_pg_connection
from embedding_engine import create_embedding



def search_chunks_for_embeddings(EmbeddedChunk):
    connection = get_pg_connection()

    try:
        cursor = connection.cursor()

        cursor.execute(
            """
            SELECT
                chunk_text,
                embedding <=> %s::vector AS distance
            FROM rag_chunks
            ORDER BY embedding <=> %s::vector
            LIMIT 1;
            """ ,(EmbeddedChunk,EmbeddedChunk)
        )

        return cursor.fetchall()

    finally:
        connection.close()

def main():

    user_input = input("Enter the word to search the closest match: ")

    EmbeddedChunk = create_embedding(user_input)    

    cloesesvalue = search_chunks_for_embeddings(EmbeddedChunk)


    print("\nClosest chunk:")
    if cloesesvalue:
        chunk_text, distance = cloesesvalue
        # Printing the string directly evaluates \n into actual line breaks
        print(chunk_text)
        print(f"\n(Distance: {distance})")
    else:
        print("No matching records found.")

    print("=" * 60)
    
    #print(f"Closess Chunks record found: {EmbeddedChunk}")

    

if __name__ == "__main__":
    main()



   